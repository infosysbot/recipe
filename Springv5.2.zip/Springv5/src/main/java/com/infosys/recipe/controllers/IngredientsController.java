package com.infosys.recipe.controllers;

import com.infosys.recipe.entity.Ingredients;
import com.infosys.recipe.repositories.IngredientsRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crud/ingredients")
public class IngredientsController {
    @Autowired
    private IngredientsRepository ingredientsRepository;

    @GetMapping
    public List<Ingredients> list() {
        return  ingredientsRepository.findAll();
    }
//
//    @GetMapping(value = "{id}")
//    public Ingredients get(@PathVariable Long id) {
//        return ingredientsRepository.getById(id);
//    }
//
//    @PostMapping
//    @ResponseStatus(HttpStatus.CREATED)
//    public Ingredients create(@RequestBody final Ingredients ingredients) {
//        return ingredientsRepository.saveAndFlush(ingredients);
//    }
//
//    @PutMapping(value = "{id}")
//    public Ingredients update(@PathVariable Long id, @RequestBody Ingredients ingredients) {
//        Ingredients existingIngredient = ingredientsRepository.getById(id);
//        BeanUtils.copyProperties(ingredients, existingIngredient, "ingredient_id");
//        return ingredientsRepository.saveAndFlush(existingIngredient);
//    }
//
//    @DeleteMapping(value = "{id}")
//    public void delete(@PathVariable Long id) {
//        ingredientsRepository.deleteById(id);
//    }
}
