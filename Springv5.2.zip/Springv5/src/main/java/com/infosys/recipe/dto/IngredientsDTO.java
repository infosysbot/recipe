package com.infosys.recipe.dto;

import java.util.List;

import com.infosys.recipe.entity.Quantity;

public class IngredientsDTO {

	private Integer ingredientID;
	
	private String ingredientName;
	
	private List<Quantity> quantityEntities;

	public Integer getIngredientID() {
		return ingredientID;
	}

	public void setIngredientID(Integer ingredientID) {
		this.ingredientID = ingredientID;
	}

	public String getIngredientName() {
		return ingredientName;
	}

	public void setIngredientName(String ingredientName) {
		this.ingredientName = ingredientName;
	}

	public List<Quantity> getQuantityEntities() {
		return quantityEntities;
	}

	public void setQuantityEntities(List<Quantity> quantityEntities) {
		this.quantityEntities = quantityEntities;
	}
	
	}
