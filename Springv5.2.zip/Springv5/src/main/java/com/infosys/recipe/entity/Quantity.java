package com.infosys.recipe.entity;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tbl_quantity")

public class Quantity {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer quantity_id;
	
    @Column(name = "quantity")
    private double quantity;
    
    @Column(name = "measurement")
    private String measurement;


	public Integer getQuantity_id() {
		return quantity_id;
	}


	public void setQuantity_id(Integer quantity_id) {
		this.quantity_id = quantity_id;
	}


	public String getMeasurement() {
		return measurement;
	}

	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}

	public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
}
