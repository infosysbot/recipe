package com.infosys.recipe.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infosys.recipe.entity.Ingredients;
import com.infosys.recipe.entity.Quantity;
import com.infosys.recipe.entity.Recipe;

@CrossOrigin("http://localhost:4200")
//@RepositoryRestResource(collectionResourceRel = "Recipe", path = "recipes")
public interface RecipeRepository extends CrudRepository<Recipe, Integer> {
   // Iterable<Recipe> findByRecipeName(String recipeName);
	List<Recipe> findAll();
	//List<Ingredients> findByRecipeID(Integer recipeId);
	List<Quantity> findByRecipeID(Integer recipeId);
} 
