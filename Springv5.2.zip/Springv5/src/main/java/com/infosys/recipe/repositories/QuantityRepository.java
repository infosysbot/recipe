package com.infosys.recipe.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infosys.recipe.entity.Quantity;

@CrossOrigin("http://localhost:4200")
//@RepositoryRestResource(collectionResourceRel = "ServingSize", path = "servingsize")
public interface QuantityRepository extends CrudRepository<Quantity, Integer> {
	List<Quantity> findAll();
}
