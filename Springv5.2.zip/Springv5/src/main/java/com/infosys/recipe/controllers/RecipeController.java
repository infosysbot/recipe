package com.infosys.recipe.controllers;

import com.infosys.recipe.entity.Ingredients;
import com.infosys.recipe.entity.Quantity;
import com.infosys.recipe.entity.Recipe;
import com.infosys.recipe.repositories.RecipeRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crud/recipes")
public class RecipeController {
    @Autowired
    private RecipeRepository recipeRepository;

    @GetMapping
    public List<Recipe> list() {
        return recipeRepository.findAll();
    }
    
    
    @GetMapping(value = "/{recipeId}")
    public List<Quantity> get(@PathVariable Integer recipeId) {
        return recipeRepository.findByRecipeID(recipeId);
    }

//    @GetMapping("/search")
//    public Iterable<Recipe> findByQuery(@RequestParam("name") String recipeName) {
//        return recipeRepository.findByRecipeName(recipeName);
//    }

//    @PostMapping
//    @ResponseStatus(HttpStatus.CREATED)
//    public Recipe create(@RequestBody final Recipe recipes) {
//        return recipeRepository.saveAndFlush(recipes);
//    }

//    @PutMapping(value = "{id}")
//    public Recipe update(@PathVariable Long id, @RequestBody Recipe recipe) {
//        Recipe existingRecipe = recipeRepository.getById(id);
//        BeanUtils.copyProperties(recipe, existingRecipe, "recipe_id");
//        return recipeRepository.saveAndFlush(existingRecipe);
//    }

//    @DeleteMapping(value = "{id}")
//    public void delete(@PathVariable Long id) {
//        recipeRepository.deleteById(id);
//    }
}

