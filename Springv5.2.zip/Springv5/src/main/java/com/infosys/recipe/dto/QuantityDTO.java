package com.infosys.recipe.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.infosys.recipe.entity.Ingredients;
import com.infosys.recipe.entity.Quantity;
import com.infosys.recipe.entity.Recipe;

public class QuantityDTO {

	private Integer quantity_id;
	
	private Double quantity;
	
	private String measurement;


	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	public String getMeasurement() {
		return measurement;
	}

	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}

	public Integer getQuantity_id() {
		return quantity_id;
	}

	public void setQuantity_id(Integer quantity_id) {
		this.quantity_id = quantity_id;
	}
	
}
