package com.infosys.recipe.dto;

import java.util.List;

import com.infosys.recipe.entity.Ingredients;
import com.infosys.recipe.entity.Quantity;

public class RecipeDTO {

	private Integer recipeID;
	
	private String recipeName;
	
	private String imageUrl;
	
    private List<Ingredients> ingredientEntities;

    private List<Quantity> quantityEntities;
	
	
	public Integer getRecipeID() {
		return recipeID;
	}

	public void setRecipeID(Integer recipeID) {
		this.recipeID = recipeID;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public List<Ingredients> getIngredientEntities() {
		return ingredientEntities;
	}

	public void setIngredientEntities(List<Ingredients> ingredientEntities) {
		this.ingredientEntities = ingredientEntities;
	}

	public List<Quantity> getQuantityEntities() {
		return quantityEntities;
	}

	public void setQuantityEntities(List<Quantity> quantityEntities) {
		this.quantityEntities = quantityEntities;
	}
}
