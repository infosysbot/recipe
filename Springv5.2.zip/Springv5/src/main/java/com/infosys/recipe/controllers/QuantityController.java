package com.infosys.recipe.controllers;

import com.infosys.recipe.entity.Quantity;
import com.infosys.recipe.repositories.QuantityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crud/quantity")
public class QuantityController {
    @Autowired
    private QuantityRepository servingsizeRepository;

    @GetMapping
    public List<Quantity> list() {
        return  servingsizeRepository.findAll();
    }

//    @GetMapping(value = "{id}")
//    public Quantity get(@PathVariable Long id) {
//        return servingsizeRepository.getById(id);
//    }

//    @PostMapping
//    @ResponseStatus(HttpStatus.CREATED)
//    public Quantity create(@RequestBody final Quantity servingsize) {
//        return servingsizeRepository.saveAndFlush(servingsize);
//    }

//    @PutMapping(value = "{id}")
//    public Quantity update(@PathVariable Long id, @RequestBody Quantity servingsize) {
//        Quantity existingServingSize = servingsizeRepository.getById(id);
//        BeanUtils.copyProperties(servingsize, existingServingSize, "recipe_id", "ingredient_id");
//        return servingsizeRepository.saveAndFlush(existingServingSize);
//    }

//    @DeleteMapping(value = "{id}")
//    public void delete(@PathVariable Long id) {
//        servingsizeRepository.deleteById(id);
//    }
}
