package com.infosys.recipe.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tbl_recipes")

public class Recipe {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recipe_id")
    private Integer recipeID;

    @Column(name = "recipe_name")
    private String recipeName;

    @Column(name = "image_url")
    private String imageUrl;

    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="recipe_id")
    private List<Ingredients> ingredientEntities;
   

	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="recipe_id")
    private List<Quantity> quantityEntities;

    public Recipe() {
    }



    public Integer getRecipeID() {
        return recipeID;
    }

    public void setRecipeID(Integer recipeID) {
        this.recipeID = recipeID;
    }



    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    public List<Ingredients> getIngredientEntities() {
		return ingredientEntities;
	}



	public void setIngredientEntities(List<Ingredients> ingredientEntities) {
		this.ingredientEntities = ingredientEntities;
	}



	public List<Quantity> getQuantityEntities() {
		return quantityEntities;
	}



	public void setQuantityEntities(List<Quantity> quantityEntities) {
		this.quantityEntities = quantityEntities;
	}
}
