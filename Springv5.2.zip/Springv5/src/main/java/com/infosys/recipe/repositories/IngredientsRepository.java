package com.infosys.recipe.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infosys.recipe.entity.Ingredients;

@CrossOrigin("http://localhost:4200")
//@RepositoryRestResource(collectionResourceRel = "Ingredients", path = "ingredients")
public interface IngredientsRepository extends CrudRepository<Ingredients, Integer> {
	List<Ingredients> findAll();
}
