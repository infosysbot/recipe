package com.infosys.recipe.entity;

import java.util.List;

import javax.persistence.*;


@Entity
@Table(name = "tbl_ingredients")

public class Ingredients {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ingredient_id")
    private Integer ingredientID;

    @Column(name = "ingredient_name")
    private String ingredientName;

    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="recipe_id")
    private List<Ingredients> Entities;

   
 

	public Integer getIngredientID() {
        return ingredientID;
    }

    public void setIngredientID(Integer ingredientID) {
        this.ingredientID = ingredientID;
    }


    public String getIngredientName() {
        return ingredientName;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

}
