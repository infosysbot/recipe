package com.infosys.recipe.repositories;

import com.infosys.recipe.models.Ingredients;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("http://localhost:4200")
@RepositoryRestResource(collectionResourceRel = "Ingredients", path = "ingredients")
public interface IngredientsRepository extends JpaRepository<Ingredients, Long> {
}
