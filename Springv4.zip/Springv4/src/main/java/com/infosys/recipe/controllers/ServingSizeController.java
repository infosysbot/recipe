package com.infosys.recipe.controllers;

import com.infosys.recipe.models.ServingSize;
import com.infosys.recipe.repositories.ServingSizeRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crud/servingsize")
public class ServingSizeController {
    @Autowired
    private ServingSizeRepository servingsizeRepository;

    @GetMapping
    public List<ServingSize> list() {
        return  servingsizeRepository.findAll();
    }

    @GetMapping(value = "{id}")
    public ServingSize get(@PathVariable Long id) {
        return servingsizeRepository.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ServingSize create(@RequestBody final ServingSize servingsize) {
        return servingsizeRepository.saveAndFlush(servingsize);
    }

    @PutMapping(value = "{id}")
    public ServingSize update(@PathVariable Long id, @RequestBody ServingSize servingsize) {
        ServingSize existingServingSize = servingsizeRepository.getById(id);
        BeanUtils.copyProperties(servingsize, existingServingSize, "recipe_id", "ingredient_id");
        return servingsizeRepository.saveAndFlush(existingServingSize);
    }

    @DeleteMapping(value = "{id}")
    public void delete(@PathVariable Long id) {
        servingsizeRepository.deleteById(id);
    }
}
