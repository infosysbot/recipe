package com.infosys.recipe.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tbl_recipes")
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Recipe {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recipe_id")
    private Integer recipeID;

//    @Id
//    @Column(name = "recipe_key")
//    private long recipeKey;

    @Column(name = "recipe_name")
    private String recipeName;

    @Column(name = "image_url")
    private String imageUrl;

//    @ManyToMany
//    @JoinTable(
//            name = "tbl_servingsize",
//            joinColumns = @JoinColumn(name = "recipe_id"),
//            inverseJoinColumns = @JoinColumn(name = "ingredient_id"))
//    private List<Ingredients> ingredients;

    public Recipe() {
    }

//    public List<Ingredients> getIngredients() {
//        return ingredients;
//    }
//
//    public void setIngredients(List<Ingredients> ingredients) {
//        this.ingredients = ingredients;
//    }

    public Integer getRecipeID() {
        return recipeID;
    }

    public void setRecipeID(Integer recipeID) {
        this.recipeID = recipeID;
    }

//    public long getRecipeKey() {
//        return recipeKey;
//    }
//
//    public void setRecipeKey(long recipeKey) {
//        this.recipeKey = recipeKey;
//    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
