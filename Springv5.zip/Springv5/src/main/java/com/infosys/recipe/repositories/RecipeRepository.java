package com.infosys.recipe.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infosys.recipe.entity.Recipe;

@CrossOrigin("http://localhost:4200")
@RepositoryRestResource(collectionResourceRel = "Recipe", path = "recipes")
public interface RecipeRepository extends JpaRepository<Recipe, Long> {
    Iterable<Recipe> findByRecipeName(String recipeName);
}
