package com.infosys.recipe.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.infosys.recipe.entity.Ingredients;

@CrossOrigin("http://localhost:4200")
@RepositoryRestResource(collectionResourceRel = "Ingredients", path = "ingredients")
public interface IngredientsRepository extends JpaRepository<Ingredients, Long> {
}
