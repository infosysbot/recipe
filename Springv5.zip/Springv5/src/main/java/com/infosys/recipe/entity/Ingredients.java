package com.infosys.recipe.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tbl_ingredients")
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Ingredients {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ingredient_id")
    private Integer ingredientID;

//    @Column(name = "ingredient_key")
//    private long ingredientKey;

    @Column(name = "ingredient_name")
    private String ingredientName;

//    @Column(name = "measurement")
//    private String measurement;

//    @ManyToMany(mappedBy = "ingredients")
//    @JsonIgnore
//    private List<Recipe> recipes;
//
//    @ManyToMany
//    @JoinTable(
//            name = "tbl_servingsize",
//            joinColumns = @JoinColumn(name = "ingredient_id"),
//            inverseJoinColumns = @JoinColumn(name = "recipe_id"))
//    private List<ServingSize> servingsize;

    public Ingredients() {
    }

//    public List<Recipe> getRecipes() {
//        return recipes;
//    }
//
//    public void setRecipes(List<Recipe> recipes) {
//        this.recipes = recipes;
//    }
//
//    public List<ServingSize> getServingsize() {
//        return servingsize;
//    }
//
//    public void setServingsize(List<ServingSize> servingsize) {
//        this.servingsize = servingsize;
//    }

    public Integer getIngredientID() {
        return ingredientID;
    }

    public void setIngredientID(Integer ingredientID) {
        this.ingredientID = ingredientID;
    }

//    public long getIngredientKey() {
//        return ingredientKey;
//    }
//
//    public void setIngredientKey(long ingredientKey) {
//        this.ingredientKey = ingredientKey;
//    }

    public String getIngredientName() {
        return ingredientName;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

//    public String getMeasurement() {
//        return measurement;
//    }
//
//    public void setMeasurement(String measurement) {
//        this.measurement = measurement;
//    }
}
