package com.infosys.recipe.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tbl_quantity")
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ServingSize {
   @Id
	private Integer id;
	
  

	@Column(name = "recipe_id")
    private Integer recipeID;

//    @Column(name = "recipe_key")
//    private long recipeKey;

    @Column(name = "ingredient_id")
    private Integer ingredientID;

//    @Column(name = "ingredient_key")
//    private long ingredientKey;

    @Column(name = "quantity")
    private double quantity;
    
    @Column(name = "measurement")
    private String measurement;

//    @ManyToMany(mappedBy = "servingsize")
//    //@JsonIgnore
//    private List<Ingredients> ingredients;
    @OneToMany(cascade = CascadeType.ALL)
//    @JoinColumn(name= "recipe_id")
    @JoinColumn(name="ingredient_id")
    private List<Ingredients> ingredients;

    public ServingSize() {
    }

    public List<Ingredients> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredients> ingredients) {
        this.ingredients = ingredients;
    }

    public Integer getRecipeID() {
        return recipeID;
    }

    public void setRecipeID(Integer recipeID) {
        this.recipeID = recipeID;
    }
    
    public Integer getId() {
    	return id;
    }

    public void setId(Integer id) {
    	this.id = id;
    }

//    public long getRecipeKey() {
//        return recipeKey;
//    }
//
//    public void setRecipeKey(long recipeKey) {
//        this.recipeKey = recipeKey;
//    }

    public Integer getIngredientID() {
        return ingredientID;
    }

    public void setIngredientID(Integer ingredientID) {
        this.ingredientID = ingredientID;
    }
//
//    public long getIngredientKey() {
//        return ingredientKey;
//    }
//
//    public void setIngredientKey(long ingredientKey) {
//        this.ingredientKey = ingredientKey;
//    }

    public String getMeasurement() {
		return measurement;
	}

	public void setMeasurement(String measurement) {
		this.measurement = measurement;
	}

	public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }
}
